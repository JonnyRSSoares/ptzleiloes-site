# Potenza Cred - TODO

## Tarefas Completadas

- [x] Replicar site existente
- [x] Adicionar link do YouTube no ícone para redirecionar ao canal @potenzacred
- [x] Testar e validar o site atualizado

## Tarefas Pendentes

- [x] Copiar e organizar as imagens (PTZ01, PTZ02, PTZ03) no projeto
- [x] Integrar logo Potenza Cred (PTZ03) no header/navbar
- [x] Integrar fundo com logo (PTZ02) na seção hero
- [x] Integrar logo PTZ com chave (PTZ01) em seção apropriada
- [x] Testar responsividade das imagens em diferentes tamanhos
- [x] Adicionar ícone PTZ01 no início de cada pergunta frequente
- [x] Atualizar número do WhatsApp para 555430458042
- [x] Remover link do LinkedIn da navbar
- [x] Adicionar imagens PTZ01 e PTZ04 como fundo na seção de perguntas frequentes
- [x] Inserir mapa interativo com localização do escritório
- [x] Adicionar imagem PTZ01 em cada resposta das perguntas frequentes
- [x] Publicar o site atualizado
- [x] Site Potenza Cred Finalizado e Pronto para Publicação
